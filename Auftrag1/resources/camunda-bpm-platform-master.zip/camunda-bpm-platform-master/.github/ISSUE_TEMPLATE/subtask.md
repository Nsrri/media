---
name: Subtask
about: An implementation step that contributes to a feature, bug fix, task, but isn't meaningful on its own
title: ''
labels: type:subtask
assignees: ''

---

### Acceptance Criteria (Required on creation)

### Hints

### Links

<!--
- https://jira.camunda.com/browse/CAM-12398
-->

### Breakdown

<!--
- [ ] #123
- [ ] Step X
-->

```[tasklist]
### Pull Requests
```