export CATALINA_OPTS="-Xmx512m"
