/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information regarding copyright
 * ownership. Camunda licenses this file to you under the Apache License,
 * Version 2.0; you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.camunda.bpm.container.impl.jboss.extension.resource;

import org.camunda.bpm.container.impl.jboss.extension.BpmPlatformExtension;
import org.camunda.bpm.container.impl.jboss.extension.SubsystemAttributeDefinitons;
import org.camunda.bpm.container.impl.jboss.extension.ModelConstants;
import org.camunda.bpm.container.impl.jboss.extension.handler.JobExecutorAdd;
import org.camunda.bpm.container.impl.jboss.extension.handler.JobExecutorRemove;
import org.jboss.as.controller.AttributeDefinition;
import org.jboss.as.controller.PersistentResourceDefinition;

import java.util.*;

public class JobExecutorDefinition extends PersistentResourceDefinition {

  public static final JobExecutorDefinition INSTANCE = new JobExecutorDefinition();

  private JobExecutorDefinition() {
    super(BpmPlatformExtension.JOB_EXECUTOR_PATH,
        BpmPlatformExtension.getResourceDescriptionResolver(ModelConstants.JOB_EXECUTOR),
        JobExecutorAdd.INSTANCE,
        JobExecutorRemove.INSTANCE);
  }

  @Override
  public Collection<AttributeDefinition> getAttributes() {
    return Arrays.asList(SubsystemAttributeDefinitons.JOB_EXECUTOR_ATTRIBUTES);
  }

  @Override
  protected List<? extends PersistentResourceDefinition> getChildren() {
    return Collections.singletonList(JobAcquisitionDefinition.INSTANCE);
  }

}
